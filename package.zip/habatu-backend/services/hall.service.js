"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteHall = exports.updateHalls = exports.getHalls = exports.getHall = exports.createHall = void 0;
const models_1 = require("../models");
const mongoose_1 = require("mongoose");
const createHall = (hall) => __awaiter(void 0, void 0, void 0, function* () {
    return yield models_1.Hall.create(hall);
});
exports.createHall = createHall;
const getHall = (_id) => __awaiter(void 0, void 0, void 0, function* () {
    if (!mongoose_1.Types.ObjectId.isValid(_id)) {
        throw new Error("");
    }
    const hall = yield models_1.Hall.findOne({ _id });
    return hall;
});
exports.getHall = getHall;
const getHalls = () => __awaiter(void 0, void 0, void 0, function* () {
    const halls = yield models_1.Hall.find({});
    return halls;
});
exports.getHalls = getHalls;
const updateHalls = (_id, newHall) => __awaiter(void 0, void 0, void 0, function* () {
    const hall = yield models_1.Hall.findOneAndUpdate({ _id }, newHall, { new: true });
    return hall;
});
exports.updateHalls = updateHalls;
const deleteHall = (_id) => __awaiter(void 0, void 0, void 0, function* () {
    yield models_1.Hall.deleteOne({ _id });
    return {};
});
exports.deleteHall = deleteHall;
