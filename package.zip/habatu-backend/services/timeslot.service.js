"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteTimeslot = exports.updateTimeslots = exports.getTimeslots = exports.getTimeslot = exports.createTimeslot = void 0;
const models_1 = require("../models");
const mongoose_1 = require("mongoose");
const createTimeslot = (timeslot) => __awaiter(void 0, void 0, void 0, function* () {
    return yield models_1.Timeslot.create(timeslot);
});
exports.createTimeslot = createTimeslot;
const getTimeslot = (_id) => __awaiter(void 0, void 0, void 0, function* () {
    if (!mongoose_1.Types.ObjectId.isValid(_id)) {
        throw new Error("");
    }
    const timeslot = yield models_1.Timeslot.findOne({ _id });
    return timeslot;
});
exports.getTimeslot = getTimeslot;
const getTimeslots = () => __awaiter(void 0, void 0, void 0, function* () {
    const timeslots = yield models_1.Timeslot.find({});
    return timeslots;
});
exports.getTimeslots = getTimeslots;
const updateTimeslots = (_id, newTimeslot) => __awaiter(void 0, void 0, void 0, function* () {
    const timeslot = yield models_1.Timeslot.findOneAndUpdate({ _id }, newTimeslot, { new: true });
    return timeslot;
});
exports.updateTimeslots = updateTimeslots;
const deleteTimeslot = (_id) => __awaiter(void 0, void 0, void 0, function* () {
    yield models_1.Timeslot.deleteOne({ _id });
    return {};
});
exports.deleteTimeslot = deleteTimeslot;
