"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteOption = exports.updateOptions = exports.getOptions = exports.getOption = exports.createOption = void 0;
const models_1 = require("../models");
const mongoose_1 = require("mongoose");
// Behaves different than other services
const createOption = (option) => __awaiter(void 0, void 0, void 0, function* () {
    let optionInstance = yield models_1.Option.findOne();
    if (!optionInstance) {
        optionInstance = yield models_1.Option.create(option);
    }
    else {
        optionInstance = yield (0, exports.updateOptions)(optionInstance._id.toString(), option);
    }
    return optionInstance;
});
exports.createOption = createOption;
const getOption = (_id) => __awaiter(void 0, void 0, void 0, function* () {
    if (!mongoose_1.Types.ObjectId.isValid(_id)) {
        throw new Error("");
    }
    const option = yield models_1.Option.findOne({ _id });
    return option;
});
exports.getOption = getOption;
const getOptions = () => __awaiter(void 0, void 0, void 0, function* () {
    const options = yield models_1.Option.findOne();
    return options;
});
exports.getOptions = getOptions;
const updateOptions = (_id, newOption) => __awaiter(void 0, void 0, void 0, function* () {
    const option = yield models_1.Option.findOneAndUpdate({ _id }, newOption, { new: true });
    return option;
});
exports.updateOptions = updateOptions;
const deleteOption = (_id) => __awaiter(void 0, void 0, void 0, function* () {
    yield models_1.Option.deleteOne({ _id });
    return {};
});
exports.deleteOption = deleteOption;
