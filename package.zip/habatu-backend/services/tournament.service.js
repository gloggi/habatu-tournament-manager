"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createFinals = exports.getTournamentRanking = exports.getTimePreview = exports.getTableByGroupId = exports.getTournamentTable = exports.getGamesPreview = void 0;
const models_1 = require("../models");
const roundRobin_1 = require("../utils/roundRobin");
const date_fns_1 = require("date-fns");
const getGamesPreview = () => __awaiter(void 0, void 0, void 0, function* () {
    const teams = yield models_1.Team.find({}, {}).lean();
    const categories = yield models_1.Category.find({}).lean();
    const halls = yield models_1.Hall.find({}).lean({ autopopulate: true });
    const option = yield models_1.Option.findOne().orFail().lean();
    const tempGames = (0, roundRobin_1.gamesGenerator)(teams, categories, halls, option);
    yield models_1.Game.deleteMany({});
    yield models_1.Timeslot.deleteMany({});
    const timeslots = yield models_1.Timeslot.insertMany((0, roundRobin_1.generateTimeslots)(tempGames, halls, option));
    const newGames = (0, roundRobin_1.allocateSlots)(tempGames, halls, timeslots);
    yield models_1.Game.insertMany(newGames);
    return yield (0, exports.getTournamentTable)();
});
exports.getGamesPreview = getGamesPreview;
const getTournamentTable = () => __awaiter(void 0, void 0, void 0, function* () {
    const halls = yield models_1.Hall.find({}).lean({ autopopulate: true });
    const option = yield models_1.Option.findOne().orFail().lean();
    const ts = yield models_1.Timeslot.find({});
    const games = yield models_1.Game.find({}).populate("hall").populate("timeslot");
    const output = {};
    for (let timeslot of ts) {
        output[`${(0, date_fns_1.format)(timeslot.startTime, "HH:mm")} - ${(0, date_fns_1.format)(timeslot.endTime, "HH:mm")}`] = {};
        output[`${(0, date_fns_1.format)(timeslot.startTime, "HH:mm")} - ${(0, date_fns_1.format)(timeslot.endTime, "HH:mm")}`]["id"] = timeslot._id;
        output[`${(0, date_fns_1.format)(timeslot.startTime, "HH:mm")} - ${(0, date_fns_1.format)(timeslot.endTime, "HH:mm")}`]["isNow"] = (0, date_fns_1.isWithinInterval)(new Date(), { start: timeslot.startTime, end: (0, date_fns_1.addMinutes)(timeslot.endTime, parseInt(option.breakDuration.split(":")[1])) });
        output[`${(0, date_fns_1.format)(timeslot.startTime, "HH:mm")} - ${(0, date_fns_1.format)(timeslot.endTime, "HH:mm")}`]["items"] = {};
        for (let hall of halls) {
            output[`${(0, date_fns_1.format)(timeslot.startTime, "HH:mm")} - ${(0, date_fns_1.format)(timeslot.endTime, "HH:mm")}`]["items"][`${hall.name}`] = { id: hall._id, items: games.filter(g => g.timeslot._id.toString() == timeslot._id.toString() && g.hall._id.toString() == hall._id.toString()) };
        }
    }
    return output;
});
exports.getTournamentTable = getTournamentTable;
const getTableByGroupId = (_id) => __awaiter(void 0, void 0, void 0, function* () {
    const games = yield models_1.Game.find({ $or: [{ teamA: _id }, { teamB: _id }] }).populate("hall").populate("timeslot").populate("teamA").populate("teamB");
    const output = {};
    for (let game of games) {
        output[`${(0, date_fns_1.format)(game.timeslot.startTime, "HH:mm")} - ${(0, date_fns_1.format)(game.timeslot.endTime, "HH:mm")}`] = game;
    }
    return output;
});
exports.getTableByGroupId = getTableByGroupId;
const getTimePreview = () => __awaiter(void 0, void 0, void 0, function* () {
    yield (0, exports.getGamesPreview)();
    const teams = yield models_1.Team.find({}, {}).lean();
    const categories = yield models_1.Category.find({}).lean();
    const halls = yield models_1.Hall.find({}).lean({ autopopulate: true });
    const option = yield models_1.Option.findOne().orFail().lean();
    const games = yield models_1.Game.find({}).populate("hall").populate("timeslot");
    return {
        amountOfGames: games.length,
        lastGame: games[games.length - 1].timeslot.endTime
    };
});
exports.getTimePreview = getTimePreview;
const getTournamentRanking = () => __awaiter(void 0, void 0, void 0, function* () {
    const teams = yield models_1.Team.find({}, {}).lean().populate("section");
    const categories = yield models_1.Category.find({}).lean();
    const games = yield models_1.Game.find({}).lean({ autopopulate: false });
    const rankedTeams = [...teams];
    for (let team of rankedTeams) {
        var tournamentPoints = 0;
        var pointsPro = 0;
        var pointsCon = 0;
        for (let game of games) {
            if (game.teamA.toString() == team._id.toString()) {
                pointsPro += game.pointsTeamA;
                pointsCon += game.pointsTeamB;
                if (game.pointsTeamA > game.pointsTeamB) {
                    tournamentPoints += 2;
                }
                if (game.pointsTeamA == game.pointsTeamB) {
                    tournamentPoints += 1;
                }
            }
            if (game.teamB.toString() == team._id.toString()) {
                pointsPro += game.pointsTeamB;
                pointsCon += game.pointsTeamA;
                if (game.pointsTeamA < game.pointsTeamB) {
                    tournamentPoints += 2;
                }
                if (game.pointsTeamA == game.pointsTeamB) {
                    tournamentPoints += 1;
                }
            }
        }
        team.tournamentPoints = tournamentPoints;
        team.pointsPro = pointsPro;
        team.pointsCon = pointsCon;
    }
    const comparefunction = (a, b) => {
        if (a.tournamentPoints > b.tournamentPoints) {
            return -1;
        }
        else if (b.tournamentPoints > a.tournamentPoints) {
            return 1;
        }
        else if (a.pointsPro > b.pointsPro) {
            return -1;
        }
        else if (b.pointsPro > a.pointsPro) {
            return 1;
        }
        else if (a.pointsCon < b.pointsCon) {
            return -1;
        }
        else if (b.pointsCon < a.pointsCon) {
            return 1;
        }
        else {
            return 0;
        }
    };
    const rankedTeamsByCategory = {};
    for (let category of categories) {
        rankedTeamsByCategory[category.name] = rankedTeams.filter((t) => t.category == category._id.toString()).sort(comparefunction);
    }
    return rankedTeamsByCategory;
});
exports.getTournamentRanking = getTournamentRanking;
const createFinals = () => __awaiter(void 0, void 0, void 0, function* () {
    const halls = yield models_1.Hall.find({}).lean({ autopopulate: true });
    const timeslots = yield models_1.Timeslot.find({}).sort({ startTime: 1 });
    const games = yield models_1.Game.find({}).populate("timeslot").sort({ "timeslot.startTime": -1 });
    const lastGameSlotId = games[games.length - 1].timeslot._id;
    console.log(timeslots.map(t => t.startTime));
    var slotIndex = timeslots.map(t => { var _a; return (_a = t._id) === null || _a === void 0 ? void 0 : _a.toString(); }).indexOf(lastGameSlotId.toString()) + 1;
    const rankedTeamsByCategory = yield (0, exports.getTournamentRanking)();
    const finals = [];
    for (let category in rankedTeamsByCategory) {
        const teams = rankedTeamsByCategory[category];
        finals.push({
            teamA: teams[0]._id.toString(),
            teamB: teams[1]._id.toString(),
            category: teams[0].category.toString(),
            type: "grandFinale",
            pointsTeamA: 0,
            pointsTeamB: 0
        });
        finals.push({
            teamA: teams[2]._id.toString(),
            teamB: teams[3]._id.toString(),
            category: teams[2].category.toString(),
            type: "petiteFinale",
            pointsTeamA: 0,
            pointsTeamB: 0
        });
    }
    for (let [i, game] of finals.entries()) {
        if (slotIndex < timeslots.length - 1 && i % halls.length == 0) {
            slotIndex++;
        }
        game.timeslot = timeslots[slotIndex]._id.toString();
        console.log(slotIndex);
        game.hall = halls[i % halls.length]._id.toString();
    }
    yield models_1.Game.insertMany(finals);
});
exports.createFinals = createFinals;
