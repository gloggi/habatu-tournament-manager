"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteGame = exports.updateGames = exports.getGames = exports.getGame = exports.createGame = void 0;
const models_1 = require("../models");
const mongoose_1 = require("mongoose");
const createGame = (game) => __awaiter(void 0, void 0, void 0, function* () {
    return yield models_1.Game.create(game);
});
exports.createGame = createGame;
const getGame = (_id) => __awaiter(void 0, void 0, void 0, function* () {
    if (!mongoose_1.Types.ObjectId.isValid(_id)) {
        throw new Error("");
    }
    const game = yield models_1.Game.findOne({ _id });
    return game;
});
exports.getGame = getGame;
const getGames = () => __awaiter(void 0, void 0, void 0, function* () {
    const games = yield models_1.Game.find({});
    return games;
});
exports.getGames = getGames;
const updateGames = (_id, newGame) => __awaiter(void 0, void 0, void 0, function* () {
    const game = yield models_1.Game.findOneAndUpdate({ _id }, newGame, { new: true });
    return game;
});
exports.updateGames = updateGames;
const deleteGame = (_id) => __awaiter(void 0, void 0, void 0, function* () {
    yield models_1.Game.deleteOne({ _id });
    return {};
});
exports.deleteGame = deleteGame;
