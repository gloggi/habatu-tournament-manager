"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteCategory = exports.updateCategorys = exports.getCategorys = exports.getCategory = exports.createCategory = void 0;
const models_1 = require("../models");
const mongoose_1 = require("mongoose");
const createCategory = (category) => __awaiter(void 0, void 0, void 0, function* () {
    return yield models_1.Category.create(category);
});
exports.createCategory = createCategory;
const getCategory = (_id) => __awaiter(void 0, void 0, void 0, function* () {
    if (!mongoose_1.Types.ObjectId.isValid(_id)) {
        throw new Error("");
    }
    const category = yield models_1.Category.findOne({ _id });
    return category;
});
exports.getCategory = getCategory;
const getCategorys = () => __awaiter(void 0, void 0, void 0, function* () {
    const categorys = yield models_1.Category.find({});
    return categorys;
});
exports.getCategorys = getCategorys;
const updateCategorys = (_id, newCategory) => __awaiter(void 0, void 0, void 0, function* () {
    const category = yield models_1.Category.findOneAndUpdate({ _id }, newCategory, { new: true });
    return category;
});
exports.updateCategorys = updateCategorys;
const deleteCategory = (_id) => __awaiter(void 0, void 0, void 0, function* () {
    yield models_1.Category.deleteOne({ _id });
    return {};
});
exports.deleteCategory = deleteCategory;
