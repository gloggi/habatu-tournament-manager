"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteSection = exports.updateSections = exports.getSections = exports.getSection = exports.createSection = void 0;
const models_1 = require("../models");
const mongoose_1 = require("mongoose");
const createSection = (section) => __awaiter(void 0, void 0, void 0, function* () {
    return yield models_1.Section.create(section);
});
exports.createSection = createSection;
const getSection = (_id) => __awaiter(void 0, void 0, void 0, function* () {
    if (!mongoose_1.Types.ObjectId.isValid(_id)) {
        throw new Error("");
    }
    const section = yield models_1.Section.findOne({ _id });
    return section;
});
exports.getSection = getSection;
const getSections = () => __awaiter(void 0, void 0, void 0, function* () {
    const sections = yield models_1.Section.find({});
    return sections;
});
exports.getSections = getSections;
const updateSections = (_id, newSection) => __awaiter(void 0, void 0, void 0, function* () {
    const section = yield models_1.Section.findOneAndUpdate({ _id }, newSection, { new: true });
    return section;
});
exports.updateSections = updateSections;
const deleteSection = (_id) => __awaiter(void 0, void 0, void 0, function* () {
    yield models_1.Section.deleteOne({ _id });
    return {};
});
exports.deleteSection = deleteSection;
