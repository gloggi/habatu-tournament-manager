"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Team = void 0;
const mongoose_1 = require("mongoose");
const mongoose_autopopulate_1 = __importDefault(require("mongoose-autopopulate"));
const schema = new mongoose_1.Schema({
    name: { type: String, required: true },
    section: { type: mongoose_1.Schema.Types.ObjectId, ref: "Section", autopopulate: true },
    category: { type: mongoose_1.Schema.Types.ObjectId, ref: "Category", autopopulate: true },
});
schema.plugin(mongoose_autopopulate_1.default);
exports.Team = (0, mongoose_1.model)('Team', schema);
