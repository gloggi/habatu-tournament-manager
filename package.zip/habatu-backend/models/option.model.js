"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Option = void 0;
const mongoose_1 = require("mongoose");
const schema = new mongoose_1.Schema({
    tournamentName: { type: String },
    startTime: { type: String },
    gameDuration: { type: String },
    breakDuration: { type: String },
    additionalSlots: { type: Number },
    startedTournament: { type: Boolean },
    endedRoundGames: { type: Boolean },
});
exports.Option = (0, mongoose_1.model)('Option', schema);
