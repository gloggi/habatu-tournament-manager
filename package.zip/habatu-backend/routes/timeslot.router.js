"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.router = void 0;
const express_1 = __importDefault(require("express"));
const timeslot_controller_1 = require("../controllers/timeslot.controller");
const middlewares_1 = require("../middlewares/middlewares");
exports.router = express_1.default.Router();
exports.router.route('/').post(middlewares_1.adminMiddleware, timeslot_controller_1.createTimeslot).get(timeslot_controller_1.getTimeslots);
exports.router.route('/:id').put(middlewares_1.adminMiddleware, timeslot_controller_1.updateTimeslot).get(timeslot_controller_1.getTimeslot).delete(middlewares_1.adminMiddleware, timeslot_controller_1.deleteTimeslot);
