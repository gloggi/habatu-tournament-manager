"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.router = void 0;
const express_1 = __importDefault(require("express"));
const tournament_controller_1 = require("../controllers/tournament.controller");
const middlewares_1 = require("../middlewares/middlewares");
exports.router = express_1.default.Router();
exports.router.route('/preview').get(tournament_controller_1.getGamesPreview);
exports.router.route('/table').get(tournament_controller_1.getTournamentTable);
exports.router.route('/time-preview').get(middlewares_1.adminMiddleware, tournament_controller_1.getTimePreview);
exports.router.route('/ranking').get(tournament_controller_1.getTournamentRanking);
exports.router.route('/create-finals').get(tournament_controller_1.createTournamentFinals);
exports.router.route('/table/:id').get(tournament_controller_1.getGroupTable);
