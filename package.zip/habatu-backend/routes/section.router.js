"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.router = void 0;
const express_1 = __importDefault(require("express"));
const section_controller_1 = require("../controllers/section.controller");
const middlewares_1 = require("../middlewares/middlewares");
exports.router = express_1.default.Router();
exports.router.route('/').post(middlewares_1.adminMiddleware, section_controller_1.createSection).get(section_controller_1.getSections);
exports.router.route('/:id').put(middlewares_1.adminMiddleware, section_controller_1.updateSection).get(section_controller_1.getSection).delete(middlewares_1.adminMiddleware, section_controller_1.deleteSection);
