"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.router = void 0;
const express_1 = __importDefault(require("express"));
const game_controller_1 = require("../controllers/game.controller");
const middlewares_1 = require("../middlewares/middlewares");
exports.router = express_1.default.Router();
exports.router.route('/').post(middlewares_1.adminMiddleware, game_controller_1.createGame).get(game_controller_1.getGames);
exports.router.route('/:id').put(game_controller_1.updateGame).get(game_controller_1.getGame).delete(middlewares_1.adminMiddleware, game_controller_1.deleteGame);
