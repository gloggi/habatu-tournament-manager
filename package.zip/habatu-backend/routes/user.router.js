"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.router = void 0;
const express_1 = __importDefault(require("express"));
const user_controller_1 = require("../controllers/user.controller");
const middlewares_1 = require("../middlewares/middlewares");
exports.router = express_1.default.Router();
exports.router.route('/').post(user_controller_1.createUser).get(middlewares_1.adminMiddleware, user_controller_1.getUsers);
exports.router.route('/login').post(user_controller_1.loginUser);
exports.router.route('/me').post(user_controller_1.getMe);
exports.router.route('/:id').put(middlewares_1.adminMiddleware, user_controller_1.updateUser).get(middlewares_1.adminMiddleware, user_controller_1.getUser).delete(middlewares_1.adminMiddleware, user_controller_1.deleteUser);
