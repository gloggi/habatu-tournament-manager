"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.router = void 0;
const section_router_1 = require("./section.router");
const team_router_1 = require("./team.router");
const category_router_1 = require("./category.router");
const game_router_1 = require("./game.router");
const hall_router_1 = require("./hall.router");
const option_router_1 = require("./option.router");
const timeslot_router_1 = require("./timeslot.router");
const user_router_1 = require("./user.router");
const tournament_router_1 = require("./tournament.router");
const express_1 = require("express");
exports.router = (0, express_1.Router)();
const routes = [
    {
        path: "/sections",
        route: section_router_1.router
    },
    {
        path: "/teams",
        route: team_router_1.router
    },
    {
        path: "/categories",
        route: category_router_1.router
    },
    {
        path: "/games",
        route: game_router_1.router
    },
    {
        path: "/halls",
        route: hall_router_1.router
    },
    {
        path: "/options",
        route: option_router_1.router
    },
    {
        path: "/timeslots",
        route: timeslot_router_1.router
    },
    {
        path: "/users",
        route: user_router_1.router
    },
    {
        path: "/tournament",
        route: tournament_router_1.router
    }
];
for (let route of routes) {
    exports.router.use(route.path, route.route);
}
