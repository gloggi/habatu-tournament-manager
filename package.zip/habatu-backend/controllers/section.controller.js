"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteSection = exports.updateSection = exports.getSections = exports.getSection = exports.createSection = void 0;
const section_service_1 = require("../services/section.service");
const createSection = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const section = yield (0, section_service_1.createSection)(req.body);
    res.json(section);
});
exports.createSection = createSection;
const getSection = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const section = yield (0, section_service_1.getSection)(req.params.id);
    res.json(section);
});
exports.getSection = getSection;
const getSections = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const sections = yield (0, section_service_1.getSections)();
    res.json(sections);
});
exports.getSections = getSections;
const updateSection = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const section = yield (0, section_service_1.updateSections)(req.params.id, req.body);
    res.json(section);
});
exports.updateSection = updateSection;
const deleteSection = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const section = yield (0, section_service_1.deleteSection)(req.params.id);
    res.json(section);
});
exports.deleteSection = deleteSection;
