"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteOption = exports.updateOption = exports.getOptions = exports.getOption = exports.createOption = void 0;
const option_service_1 = require("../services/option.service");
const createOption = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const option = yield (0, option_service_1.createOption)(req.body);
    res.json(option);
});
exports.createOption = createOption;
const getOption = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const option = yield (0, option_service_1.getOption)(req.params.id);
    res.json(option);
});
exports.getOption = getOption;
const getOptions = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const options = yield (0, option_service_1.getOptions)();
    res.json(options);
});
exports.getOptions = getOptions;
const updateOption = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const option = yield (0, option_service_1.updateOptions)(req.params.id, req.body);
    res.json(option);
});
exports.updateOption = updateOption;
const deleteOption = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const option = yield (0, option_service_1.deleteOption)(req.params.id);
    res.json(option);
});
exports.deleteOption = deleteOption;
