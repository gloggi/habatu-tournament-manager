"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteUser = exports.updateUser = exports.getUsers = exports.getUser = exports.getMe = exports.loginUser = exports.createUser = void 0;
const user_service_1 = require("../services/user.service");
const bcryptjs_1 = __importDefault(require("bcryptjs"));
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const createUser = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const encryptedPassword = yield bcryptjs_1.default.hash(req.body.password, 10);
        req.body.password = encryptedPassword;
        const user = yield (0, user_service_1.createUser)(req.body);
        const token = jsonwebtoken_1.default.sign({ _id: user._id, nickname: user.nickname, roles: user.roles }, process.env.TOKEN_KEY, {
            expiresIn: "12h",
        });
        res.status(201).json({ _id: user._id, nickname: user.nickname, roles: user.roles, token });
    }
    catch (err) {
        console.log(err);
    }
});
exports.createUser = createUser;
const loginUser = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { nickname, password } = req.body;
    const user = yield (0, user_service_1.getUserByNickname)(nickname);
    if (!user) {
        res.status(404).json({ message: "User doesn't exist in the database" });
        return;
    }
    const correctPassword = yield bcryptjs_1.default.compare(password, user.password);
    if (!correctPassword) {
        res.status(403).json({ message: "User credentials are wrong" });
        return;
    }
    const token = jsonwebtoken_1.default.sign({ _id: user._id, nickname: user.nickname, roles: user.roles }, process.env.TOKEN_KEY, {
        expiresIn: "12h",
    });
    res.status(201).json({ _id: user._id, roles: user.roles, nickname, token });
});
exports.loginUser = loginUser;
const getMe = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const { token } = req.body;
    const tokenUser = jsonwebtoken_1.default.verify(token, process.env.TOKEN_KEY);
    const user = yield (0, user_service_1.getUser)(tokenUser._id);
    console.log(user);
    if (user) {
        const token = jsonwebtoken_1.default.sign({ _id: user._id, nickname: user.nickname, roles: user.roles, team: user.team }, process.env.TOKEN_KEY, {
            expiresIn: "12h",
        });
        res.status(200).json({ _id: user._id, roles: user.roles, team: user.team, nickname: user.nickname, token });
    }
    else {
        res.status(404);
    }
});
exports.getMe = getMe;
const getUser = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const user = yield (0, user_service_1.getUser)(req.params.id);
    res.json(user);
});
exports.getUser = getUser;
const getUsers = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const users = yield (0, user_service_1.getUsers)();
    res.json(users);
});
exports.getUsers = getUsers;
const updateUser = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const user = yield (0, user_service_1.updateUsers)(req.params.id, req.body);
    console.log(user);
    res.json(user);
});
exports.updateUser = updateUser;
const deleteUser = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const user = yield (0, user_service_1.deleteUser)(req.params.id);
    res.json(user);
});
exports.deleteUser = deleteUser;
