"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteTimeslot = exports.updateTimeslot = exports.getTimeslots = exports.getTimeslot = exports.createTimeslot = void 0;
const timeslot_service_1 = require("../services/timeslot.service");
const createTimeslot = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const timeslot = yield (0, timeslot_service_1.createTimeslot)(req.body);
    res.json(timeslot);
});
exports.createTimeslot = createTimeslot;
const getTimeslot = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const timeslot = yield (0, timeslot_service_1.getTimeslot)(req.params.id);
    res.json(timeslot);
});
exports.getTimeslot = getTimeslot;
const getTimeslots = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const timeslots = yield (0, timeslot_service_1.getTimeslots)();
    res.json(timeslots);
});
exports.getTimeslots = getTimeslots;
const updateTimeslot = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const timeslot = yield (0, timeslot_service_1.updateTimeslots)(req.params.id, req.body);
    res.json(timeslot);
});
exports.updateTimeslot = updateTimeslot;
const deleteTimeslot = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const timeslot = yield (0, timeslot_service_1.deleteTimeslot)(req.params.id);
    res.json(timeslot);
});
exports.deleteTimeslot = deleteTimeslot;
