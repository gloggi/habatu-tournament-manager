"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getGroupTable = exports.createTournamentFinals = exports.getTournamentRanking = exports.getTournamentTable = exports.getTimePreview = exports.getGamesPreview = void 0;
const tournament_service_1 = require("../services/tournament.service");
const getGamesPreview = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const games = yield (0, tournament_service_1.getGamesPreview)();
    res.json(games);
});
exports.getGamesPreview = getGamesPreview;
const getTimePreview = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const preview = yield (0, tournament_service_1.getTimePreview)();
    res.json(preview);
});
exports.getTimePreview = getTimePreview;
const getTournamentTable = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const games = yield (0, tournament_service_1.getTournamentTable)();
    res.json(games);
});
exports.getTournamentTable = getTournamentTable;
const getTournamentRanking = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const ranking = yield (0, tournament_service_1.getTournamentRanking)();
    res.json(ranking);
});
exports.getTournamentRanking = getTournamentRanking;
const createTournamentFinals = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    yield (0, tournament_service_1.createFinals)();
    res.json({ message: "Finals Created" });
});
exports.createTournamentFinals = createTournamentFinals;
const getGroupTable = (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const table = yield (0, tournament_service_1.getTableByGroupId)(req.params.id);
    res.json(table);
});
exports.getGroupTable = getGroupTable;
