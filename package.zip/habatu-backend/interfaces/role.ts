export enum Role {
    Admin ="Admin",
    Referee ="Referee",
    Teammember ="Teammember"
}