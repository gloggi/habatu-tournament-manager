"use strict";
var Role;
(function (Role) {
    Role[Role["Admin"] = 0] = "Admin";
    Role[Role["Referee"] = 1] = "Referee";
    Role[Role["Teammember"] = 2] = "Teammember";
})(Role || (Role = {}));
