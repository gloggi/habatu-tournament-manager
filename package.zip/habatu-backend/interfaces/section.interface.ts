export interface ISection {
    name: string;
  }