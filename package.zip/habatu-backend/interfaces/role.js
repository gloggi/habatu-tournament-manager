"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Role = void 0;
var Role;
(function (Role) {
    Role["Admin"] = "Admin";
    Role["Referee"] = "Referee";
    Role["Teammember"] = "Teammember";
})(Role = exports.Role || (exports.Role = {}));
