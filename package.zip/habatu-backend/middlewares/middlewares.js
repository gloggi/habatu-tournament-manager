"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.refereeMiddleware = exports.adminMiddleware = void 0;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const role_1 = require("../interfaces/role");
const adminMiddleware = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (!token) {
        res.sendStatus(401);
        return;
    }
    try {
        const user = jsonwebtoken_1.default.verify(token, process.env.TOKEN_KEY);
        res.locals.user = user;
        if (!user.roles.includes(role_1.Role.Admin)) {
            res.sendStatus(401).json({ message: "Finger wäg!" });
            return;
        }
        next();
    }
    catch (e) {
        throw Error(e.message);
    }
};
exports.adminMiddleware = adminMiddleware;
const refereeMiddleware = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (!token) {
        res.sendStatus(401);
        return;
    }
    try {
        const user = jsonwebtoken_1.default.verify(token, process.env.TOKEN_KEY);
        res.locals.user = user;
        if (!user.roles.includes(role_1.Role.Referee) || !user.roles.includes(role_1.Role.Admin)) {
            res.sendStatus(401).json({ message: "Finger wäg!" });
            return;
        }
        next();
    }
    catch (e) {
        throw Error(e.message);
    }
};
exports.refereeMiddleware = refereeMiddleware;
