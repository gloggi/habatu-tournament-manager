
const roundRobin = (cTeams)=>{
    var roundTeams = []
    var endTeam = undefined
    if(!(cTeams.length%2)){
       roundTeams = cTeams.slice(0, cTeams.length-1)
       endTeam = cTeams[cTeams.length-1]
    }else{
        roundTeams = cTeams
    }
       const allGames = []
       for(let i=0;i<roundTeams.length;i++){
        const pivotTeam = roundTeams[i]
        if(!(cTeams.length%2)){
        allGames.push([pivotTeam, endTeam])
    }
        for(let j=1;j<cTeams.length/2;j++){
            const teamA = roundTeams[(i+j)%roundTeams.length]
            const teamB = roundTeams[(i-j+roundTeams.length)%roundTeams.length]
            allGames.push([teamA, teamB])
        }
        
       }
       console.log(allGames)
}

cTeams = ["Max", "Fritz", "Melanie", "Rosalie", "Anna"]

roundRobin(cTeams)