"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.allocateSlots = exports.generateTimeslots = exports.gamesGenerator = void 0;
const lodash_1 = require("lodash");
const helper_1 = require("./helper");
const date_fns_1 = require("date-fns");
const gamesGenerator = (teams, categories, halls, option) => {
    const teamsByCategory = {};
    for (let category of categories) {
        teamsByCategory[category._id.toString()] = teams.filter((team) => team.category == category._id.toString());
    }
    const gamesByCategory = {};
    for (let category in teamsByCategory) {
        gamesByCategory[category] = [];
        const cTeams = teamsByCategory[category];
        var roundTeams = [];
        if (!(cTeams.length % 2)) {
            roundTeams = cTeams.slice(0, cTeams.length - 1);
        }
        else {
            roundTeams = cTeams;
        }
        for (let i = 0; i < roundTeams.length; i++) {
            const pivotTeam = roundTeams[i];
            if (!(cTeams.length % 2)) {
                var endTeam = cTeams[cTeams.length - 1];
                gamesByCategory[category].push({
                    teamA: pivotTeam._id.toString(),
                    teamB: endTeam._id.toString(),
                    category: category,
                    type: "roundGame",
                    pointsTeamA: 0,
                    pointsTeamB: 0
                });
            }
            for (let j = 1; j < cTeams.length / 2; j++) {
                const teamA = roundTeams[(i + j) % roundTeams.length];
                const teamB = roundTeams[(i - j + roundTeams.length) % roundTeams.length];
                gamesByCategory[category].push({
                    teamA: teamA._id.toString(),
                    teamB: teamB._id.toString(),
                    category: category,
                    type: "roundGame",
                    pointsTeamA: 0,
                    pointsTeamB: 0
                });
            }
        }
    }
    const tempGames = [];
    for (let category in teamsByCategory) {
        tempGames.push(gamesByCategory[category]);
    }
    const games = (0, lodash_1.flattenDeep)((0, lodash_1.zip)(...tempGames)).filter(g => g);
    return games;
};
exports.gamesGenerator = gamesGenerator;
const generateTimeslots = (games, halls, option) => {
    const nslots = Math.ceil(games.length / halls.length) + option.additionalSlots;
    const timeSlots = [];
    let startTime = (0, helper_1.setTimeOnDate)(new Date(), option.startTime);
    console.log(startTime);
    for (let i = 0; i < nslots; i++) {
        timeSlots.push({
            startTime: startTime,
            endTime: (0, date_fns_1.addMinutes)(startTime, parseInt(option.gameDuration.split(":")[1])),
        });
        startTime = (0, date_fns_1.addMinutes)(startTime, parseInt(option.gameDuration.split(":")[1]) + parseInt(option.breakDuration.split(":")[1]));
    }
    return timeSlots;
};
exports.generateTimeslots = generateTimeslots;
const allocateSlots = (games, halls, timeslots) => {
    let slotCounter = 0;
    for (const [i, game] of games.entries()) {
        const hallIndex = i % halls.length;
        game.hall = halls[hallIndex]._id.toString();
        game.timeslot = timeslots[slotCounter]._id;
        if (hallIndex == halls.length - 1) {
            slotCounter++;
        }
    }
    return games;
};
exports.allocateSlots = allocateSlots;
