"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.setTimeOnDate = void 0;
const date_fns_1 = require("date-fns");
const setTimeOnDate = (date, time) => {
    const [hours, minutes] = time.split(":").map(n => parseInt(n));
    let newDate = (0, date_fns_1.setHours)(date, hours);
    newDate = (0, date_fns_1.setMinutes)(newDate, minutes);
    return newDate;
};
exports.setTimeOnDate = setTimeOnDate;
